const $ = (s) => document.querySelector(s);
const state = { clients: [], nodes: [], stats: {} };

async function api(path, options={}) {
  const r = await fetch(path, { credentials:"include", headers:{"Content-Type":"application/json",...(options.headers||{})}, ...options });
  if (r.status === 204) return null;
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "خطا");
  return data;
}

function loginView(error="") {
  $("#app").innerHTML = `<div class="login-wrap"><form id="login" class="card login">
    <div class="brand">RXT</div><h1>Config Panel</h1><p>ورود مدیر</p>
    <input id="user" placeholder="نام کاربری" autocomplete="username" required>
    <input id="pass" placeholder="رمز عبور" type="password" autocomplete="current-password" required>
    ${error?`<div class="error">${error}</div>`:""}
    <button>ورود</button>
  </form></div>`;
  $("#login").onsubmit = async e => {
    e.preventDefault();
    try { await api("/api/auth/login",{method:"POST",body:JSON.stringify({username:$("#user").value,password:$("#pass").value})}); render(); }
    catch(err){ loginView(err.message); }
  };
}

function stat(title,value){ return `<div class="card stat"><span>${title}</span><strong>${value}</strong></div>`; }

async function render() {
  try { state.stats=await api("/api/stats"); state.clients=await api("/api/clients"); state.nodes=await api("/api/nodes"); }
  catch { return loginView(); }
  $("#app").innerHTML = `
  <header><div class="logo">RXT <small>Config Panel</small></div><button id="logout" class="secondary">خروج</button></header>
  <main>
    <section class="stats">${stat("کاربران",state.stats.users)}${stat("فعال",state.stats.active)}${stat("نودهای فعال",state.stats.nodes)}${stat("حجم کل",`${state.stats.traffic.total} GB`)}</section>
    <section class="grid">
      <form id="clientForm" class="card">
        <h2>ساخت کانفیگ</h2>
        <div class="formgrid">
          <input id="cuser" placeholder="نام کاربر" required>
          <select id="protocol"><option>vless</option><option>vmess</option><option>trojan</option><option>shadowsocks</option><option>wireguard</option></select>
          <select id="node"><option value="">بدون Node</option>${state.nodes.map(n=>`<option value="${n.id}">${esc(n.name)} — ${esc(n.address)}</option>`).join("")}</select>
          <input id="server" placeholder="Server" value="example.com">
          <input id="port" type="number" value="443" placeholder="Port">
          <input id="traffic" type="number" value="50" placeholder="حجم GB">
          <input id="days" type="number" value="30" placeholder="روز">
          <input id="devices" type="number" value="1" placeholder="دستگاه">
        </div>
        <button>ایجاد</button>
      </form>
      <form id="nodeForm" class="card">
        <h2>افزودن Node</h2>
        <div class="formgrid">
          <input id="nname" placeholder="نام Node" required>
          <input id="naddr" placeholder="IP / Domain" required>
          <input id="nport" type="number" value="443" placeholder="Port">
          <select id="nproto"><option>vless</option><option>vmess</option><option>trojan</option><option>shadowsocks</option><option>wireguard</option></select>
        </div><button>افزودن Node</button>
      </form>
    </section>
    <section class="card">
      <div class="head"><h2>کاربران</h2><button id="refresh" class="secondary">بروزرسانی</button></div>
      <div class="table"><div class="tr th"><span>کاربر</span><span>پروتکل</span><span>حجم</span><span>انقضا</span><span>عملیات</span></div>
      ${state.clients.map(c=>`<div class="tr"><span><b>${esc(c.username)}</b><small>${esc(c.server||"")}</small></span><span>${esc(c.protocol)}</span><span>${c.used_gb}/${c.traffic_gb} GB</span><span>${new Date(c.expires_at).toLocaleDateString("fa-IR")}</span><span class="actions"><button onclick="showConfig(${c.id})">کانفیگ</button><button class="secondary" onclick="sub(${c.id})">اشتراک</button><button class="secondary" onclick="toggleClient(${c.id})">${c.enabled?"غیرفعال":"فعال"}</button><button class="danger" onclick="removeClient(${c.id})">حذف</button></span></div>`).join("")}
      </div>
    </section>
    <section class="card"><h2>Nodeها</h2>${state.nodes.length?state.nodes.map(n=>`<div class="node"><span><b>${esc(n.name)}</b><small>${esc(n.address)}:${n.port}</small></span><button class="danger" onclick="removeNode(${n.id})">حذف</button></div>`).join(""):`<p class="muted">هنوز Node ثبت نشده است.</p>`}</section>
  </main>`;
  $("#logout").onclick=async()=>{await api("/api/auth/logout",{method:"POST"});loginView()};
  $("#refresh").onclick=render;
  $("#clientForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/clients",{method:"POST",body:JSON.stringify({username:$("#cuser").value,protocol:$("#protocol").value,node_id:$("#node").value||null,server:$("#server").value,port:+$("#port").value,traffic_gb:+$("#traffic").value,days:+$("#days").value,device_limit:+$("#devices").value})});render()}catch(x){alert(x.message)}};
  $("#nodeForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/nodes",{method:"POST",body:JSON.stringify({name:$("#nname").value,address:$("#naddr").value,port:+$("#nport").value,protocol:$("#nproto").value})});render()}catch(x){alert(x.message)}};
}

async function showConfig(id){
  try{const x=await api(`/api/clients/${id}/config`);$("#modal")?.remove();document.body.insertAdjacentHTML("beforeend",`<div id="modal" class="modal"><div class="card modalbox"><div class="head"><h2>کانفیگ</h2><button class="secondary" onclick="$('#modal').remove()">بستن</button></div><img class="qr" src="${x.qr}"><textarea readonly>${x.config}</textarea><button onclick="navigator.clipboard.writeText(${JSON.stringify(x.config)})">کپی</button></div></div>`)}catch(e){alert(e.message)}
}
async function sub(id){try{const x=await api(`/api/clients/${id}/subscription`);prompt("لینک اشتراک:",x.url)}catch(e){alert(e.message)}}
async function toggleClient(id){try{await api(`/api/clients/${id}/toggle`,{method:"PATCH"});render()}catch(e){alert(e.message)}}
async function removeClient(id){if(confirm("حذف کاربر؟")){await api(`/api/clients/${id}`,{method:"DELETE"});render()}}
async function removeNode(id){if(confirm("حذف Node؟")){await api(`/api/nodes/${id}`,{method:"DELETE"});render()}}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
render();
